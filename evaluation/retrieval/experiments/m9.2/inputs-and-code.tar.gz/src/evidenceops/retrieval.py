"""Index and search a small exact pgvector corpus; no HTTP or generation."""

from dataclasses import dataclass
import logging
from time import perf_counter
from uuid import UUID
from typing import Literal

from sqlalchemy import delete, select
from sqlalchemy.orm import Session, sessionmaker

from evidenceops.chunking import RetrievableUnit, build_retrievable_unit
from evidenceops.embeddings import (
    EmbeddingCompatibilityError, MedCPTConfig, MedCPTEncoder, article_inputs,
    validate_config, validate_vector,
)
from evidenceops.lexical import CANDIDATE_K, bm25, reciprocal_rank_fusion
from evidenceops.models import Publication, UnitEmbedding
from evidenceops.publications import as_biomedical_document
from evidenceops.reranking import MedCPTReranker, RERANK_CANDIDATES, validate_scores


def _unit(publication: Publication) -> RetrievableUnit | None:
    return build_retrievable_unit(as_biomedical_document(publication), publication_id=publication.id)


def _compatible(row: UnitEmbedding, config: MedCPTConfig) -> None:
    if row.configuration != config.metadata() or row.strategy != config.strategy:
        raise EmbeddingCompatibilityError("Corpus configuration differs; explicitly rebuild incompatible rows")


def index_publication(
    sessions: sessionmaker[Session], publication_id: UUID, encoder: MedCPTEncoder,
    *, replace_incompatible: bool = False,
) -> str:
    """Return indexed/unchanged/omitted. Own commits, no DB connection during encoding.

    Serialize the final write on the publication. If the source changes during
    encoding, abort rather than persist a vector for a superseded snapshot.
    Explicit replacement is per publication; search rejects a mixed corpus
    until all incompatible rows have been rebuilt.
    """
    validate_config(encoder.config)
    with sessions.begin() as session:
        publication = session.get(Publication, publication_id)
        if publication is None:
            raise ValueError("Publication does not exist")
        unit = _unit(publication)
        existing = session.scalar(select(UnitEmbedding).where(UnitEmbedding.publication_id == publication_id))
        if existing is not None and not replace_incompatible:
            _compatible(existing, encoder.config)
        if unit is not None and existing is not None:
            if (existing.unit_id == unit.unit_id
                    and existing.content_fingerprint == unit.content_fingerprint
                    and existing.configuration == encoder.config.metadata()
                    and existing.strategy == unit.strategy
                    and article_inputs(existing.source_title, existing.source_abstract)
                    == article_inputs(unit.title, unit.abstract)):
                # Exact source fields can change without changing represented text.
                existing.source_title = publication.title
                existing.source_abstract = publication.abstract
                return "unchanged"

    vector = validate_vector(encoder.encode_article(unit)) if unit is not None else None
    with sessions.begin() as session:
        publication = session.scalar(select(Publication).where(Publication.id == publication_id).with_for_update())
        if publication is None or _unit(publication) != unit:
            raise RuntimeError("Publication changed during indexing; retry explicitly")
        existing = session.scalar(select(UnitEmbedding).where(UnitEmbedding.publication_id == publication_id))
        if existing is not None and not replace_incompatible:
            _compatible(existing, encoder.config)
        if unit is None:
            session.execute(delete(UnitEmbedding).where(UnitEmbedding.publication_id == publication_id))
            return "omitted"
        if existing is not None:
            session.delete(existing)
            session.flush()
        session.add(UnitEmbedding(
            unit_id=unit.unit_id, publication_id=publication_id, strategy=unit.strategy,
            content_fingerprint=unit.content_fingerprint, text=unit.text,
            source_title=publication.title, source_abstract=publication.abstract,
            configuration=encoder.config.metadata(), vector=vector,
        ))
    return "indexed"


@dataclass(frozen=True, slots=True)
class RetrievalResult:
    unit: RetrievableUnit
    score: float


@dataclass(frozen=True, slots=True)
class RerankedResult(RetrievalResult):
    # Keep the base schema stable: archived RAG runs use its canonical digest.
    retrieval_score: float


def _search_first_stage(
    sessions: sessionmaker[Session], encoder: MedCPTEncoder, *, query: str,
    top_k: int, published_from: int | None = None,
    mode: Literal["semantic", "hybrid"] = "semantic", candidate_k: int = CANDIDATE_K,
) -> list[RetrievalResult]:
    """Semantic dot product or BM25/semantic RRF; stable unit_id tie break.

    Hybrid fuses max(top_k, candidate_k) candidates per branch with RRF.
    BM25 statistics use the same eligible corpus, without zero-match candidates.
    Empty/filtered corpus returns []. Unknown year fails a temporal filter.
    Fewer candidates returns fewer results, without padding.
    """
    if not isinstance(query, str) or not query.strip():
        raise ValueError("Query must contain text")
    if type(top_k) is not int or top_k <= 0:
        raise ValueError("top_k must be a positive integer")
    if published_from is not None and (type(published_from) is not int or published_from <= 0):
        raise ValueError("published_from must be a positive year")
    if mode not in ("semantic", "hybrid"):
        raise ValueError("mode must be semantic or hybrid")
    if type(candidate_k) is not int or candidate_k <= 0:
        raise ValueError("candidate_k must be a positive integer")
    validate_config(encoder.config)
    # Encode outside DB transaction. Empty corpus still validates the encoder output.
    vector = validate_vector(encoder.encode_query(query.strip()))
    with sessions() as session:
        incompatible = session.scalar(select(UnitEmbedding.unit_id).where(
            (UnitEmbedding.configuration != encoder.config.metadata())
            | (UnitEmbedding.strategy != encoder.config.strategy)
        ).limit(1))
        if incompatible is not None:
            raise EmbeddingCompatibilityError("Corpus configuration differs; rebuild before search")
        distance = UnitEmbedding.vector.max_inner_product(vector)
        statement = select(Publication, UnitEmbedding, (-distance).label("score")).join(
            UnitEmbedding, UnitEmbedding.publication_id == Publication.id,
        ).where(
            UnitEmbedding.configuration == encoder.config.metadata(),
            UnitEmbedding.strategy == encoder.config.strategy,
            UnitEmbedding.source_title == Publication.title,
            UnitEmbedding.source_abstract.is_not_distinct_from(Publication.abstract),
        )
        if published_from is not None:
            statement = statement.where(Publication.publication_year >= published_from)
        # One statement gives hybrid rankings a shared corpus snapshot.
        ranked = statement.order_by(distance, UnitEmbedding.unit_id)
        rows = session.execute(ranked.limit(top_k) if mode == "semantic" else ranked).all()
        results = []
        for publication, embedding, score in rows:
            unit = _unit(publication)
            # Also guard stored identity/fingerprint/text against inconsistent rows.
            if (unit is None or unit.unit_id != embedding.unit_id
                    or unit.content_fingerprint != embedding.content_fingerprint
                    or unit.text != embedding.text):
                raise EmbeddingCompatibilityError("Stored unit differs from source; reindex")
            results.append(RetrievalResult(unit=unit, score=float(score)))
        if mode == "hybrid":
            depth = max(top_k, candidate_k)
            lexical = bm25([result.unit for result in results], query)[:depth]
            semantic = [(result.unit, result.score) for result in results[:depth]]
            return [RetrievalResult(unit, score) for unit, score in
                    reciprocal_rank_fusion([semantic, lexical])[:top_k]]
        return results


def search(
    sessions: sessionmaker[Session], encoder: MedCPTEncoder, *, query: str,
    top_k: int, published_from: int | None = None,
    mode: Literal["semantic", "hybrid", "reranking"] = "semantic",
    candidate_k: int = CANDIDATE_K, reranker: MedCPTReranker | None = None,
    timings: dict | None = None,
) -> list[RetrievalResult]:
    """Search with an optional fixed top-20 semantic → Cross-Encoder stage.

    Reranking accepts top_k <= 20 (RAG requests 5). Filters and compatibility
    checks precede candidate selection. Ties use unit_id, never input order.
    Timings include encoding/SQL and scoring (tokenization + forward + any lazy
    load), respectively; total includes orchestration. No silent fallback.
    """
    if mode not in ("semantic", "hybrid", "reranking"):
        raise ValueError("mode must be semantic, hybrid or reranking")
    if mode == "reranking":
        if type(top_k) is not int or not 0 < top_k <= RERANK_CANDIDATES:
            raise ValueError("reranking top_k must be between 1 and 20")
        if reranker is None:
            raise ValueError("reranking requires a MedCPT reranker")
    started = perf_counter()
    results = _search_first_stage(
        sessions, encoder, query=query,
        top_k=RERANK_CANDIDATES if mode == "reranking" else top_k,
        published_from=published_from, mode="semantic" if mode == "reranking" else mode,
        candidate_k=candidate_k,
    )
    retrieved = perf_counter()
    if mode == "reranking" and results:
        scores = validate_scores(reranker.score(query.strip(), [r.unit for r in results]), len(results))
        results = sorted(
            [RerankedResult(r.unit, score, r.score) for r, score in zip(results, scores, strict=True)],
            key=lambda r: (-r.score, r.unit.unit_id),
        )[:top_k]
        logging.getLogger(__name__).info("retrieval.reranked", extra={
            "reranker_model": reranker.config.model, "reranker_revision": reranker.config.revision,
            "candidate_count": len(scores),
        })
    finished = perf_counter()
    if timings is not None:
        timings.update(retrieval_seconds=retrieved - started,
                       reranker_seconds=finished - retrieved if mode == "reranking" and results else 0.0,
                       total_seconds=finished - started)
    return results
